WEBSITE KELAS 9B MUHAMMADIYAH 2 CIREBON
Versi: Vercel + Supabase Database + Storage

FITUR
- Tidak menggunakan manifest.json.
- Tidak menggunakan localStorage untuk data anggota atau galeri.
- Data anggota dan galeri tersimpan di database online.
- Foto dikompres di perangkat sebelum dikirim sehingga upload lebih ringan.
- Foto disimpan di Supabase Storage dan URL-nya disimpan di database.
- Jika HP 1 mengunggah foto, HP 2 akan melihat foto yang sama setelah memuat ulang halaman.
- Mode Gelap/Terang tetap lokal pada masing-masing perangkat.
- Logo Muhammadiyah tetap embedded di index.html.
- Developer mencantumkan DIDO ZAID AL HABSYI.

DEPLOY KE VERCEL
1. Buat project di Supabase.
2. Buka SQL Editor Supabase.
3. Jalankan file supabase.sql sampai selesai.
4. Ambil Project URL dari Supabase.
5. Ambil Service Role Key dari Supabase Project Settings > API. Jangan pernah menaruh key ini di index.html atau GitHub.
6. Upload folder ini ke GitHub atau import project ke Vercel.
7. Di Vercel, buka Project Settings > Environment Variables.
8. Tambahkan:
   SUPABASE_URL = URL project Supabase
   SUPABASE_SERVICE_ROLE_KEY = Service Role Key Supabase
9. Redeploy Vercel.

PENTING
- Service Role Key hanya boleh berada di Environment Variables Vercel.
- Jangan mengubah api/data.js menjadi kode frontend.
- File ini sengaja tidak membuat manifest.json.
- Endpoint GET /api/data membaca database. Endpoint POST/DELETE digunakan website untuk sinkronisasi data.

FORMAT FOTO
Website menerima JPG, PNG, dan WEBP. Foto otomatis diperkecil menjadi JPEG maksimal sekitar 1600px sebelum upload.
Jika foto HEIC tidak terbaca di WebView tertentu, simpan/export foto sebagai JPG lalu upload.
