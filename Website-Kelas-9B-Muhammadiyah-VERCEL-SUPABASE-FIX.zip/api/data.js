const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const BUCKET = "kelas9b";

function json(res, status, body) {
  res.status(status).setHeader("Cache-Control", "no-store").json(body);
}

function requireConfig(res) {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    json(res, 500, { error: "SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY belum diatur di Vercel." });
    return false;
  }
  return true;
}

async function supabase(path, options = {}) {
  const response = await fetch(`${SUPABASE_URL}${path}`, {
    ...options,
    headers: {
      apikey: SUPABASE_SERVICE_ROLE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      ...(options.headers || {})
    }
  });
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = text; }
  if (!response.ok) throw new Error(data?.message || data?.error || `Supabase error ${response.status}`);
  return data;
}

function cleanId(value) {
  return String(value || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 100);
}

function decodeDataUrl(dataUrl) {
  const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ""));
  if (!match) throw new Error("Format foto tidak valid.");
  return { contentType: match[1], buffer: Buffer.from(match[2], "base64") };
}

async function uploadImage(image, folder, id) {
  const { contentType, buffer } = decodeDataUrl(image.dataUrl || `data:${image.contentType};base64,${image.base64}`);
  if (buffer.length > 1600000) throw new Error("Foto terlalu besar. Gunakan foto yang lebih kecil.");
  const ext = contentType === "image/png" ? "png" : contentType === "image/webp" ? "webp" : "jpg";
  const path = `${folder}/${cleanId(id)}-${Date.now()}.${ext}`;
  await supabase(`/storage/v1/object/${BUCKET}/${path}`, {
    method: "POST",
    headers: { "Content-Type": contentType, "x-upsert": "true", "cache-control": "31536000" },
    body: buffer
  });
  return { path, url: `${SUPABASE_URL}/storage/v1/object/public/${BUCKET}/${path}` };
}

async function removeImage(path) {
  if (!path) return;
  try { await supabase(`/storage/v1/object/${BUCKET}`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify([path]) }); } catch (_) {}
}

export default async function handler(req, res) {
  if (!requireConfig(res)) return;
  try {
    const parts = req.url.split("?")[0].split("/").filter(Boolean);
    const action = parts[parts.length - 1] || "";
    if (req.method === "GET") {
      const [members, gallery] = await Promise.all([
        supabase(`/rest/v1/members?select=*&order=created_at.desc`),
        supabase(`/rest/v1/gallery?select=*&order=created_at.desc`)
      ]);
      return json(res, 200, { members, gallery });
    }
    if (req.method === "POST" && (action === "member" || action === "gallery")) {
      const body = req.body || {};
      const id = cleanId(body.id) || `${action}-${Date.now()}`;
      if (action === "member") {
        if (!body.name) return json(res, 400, { error: "Nama siswa wajib diisi." });
        let photo = body.oldPhoto || null;
        let photo_path = body.oldPhotoPath || null;
        if (body.image?.base64 || body.image?.dataUrl) {
          const uploaded = await uploadImage(body.image, "members", id);
          if (photo_path) await removeImage(photo_path);
          photo = uploaded.url; photo_path = uploaded.path;
        }
        const row = { id, name: String(body.name).slice(0, 60), role: String(body.role || "Siswa").slice(0, 50), photo, photo_path };
        const data = await supabase(`/rest/v1/members?on_conflict=id`, { method: "POST", headers: { "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=representation" }, body: JSON.stringify(row) });
        return json(res, 200, { item: data[0] || row });
      }
      if (!body.title || !body.image) return json(res, 400, { error: "Judul dan foto wajib diisi." });
      const uploaded = await uploadImage(body.image, "gallery", id);
      const row = { id, title: String(body.title).slice(0, 60), photo: uploaded.url, photo_path: uploaded.path };
      const data = await supabase(`/rest/v1/gallery`, { method: "POST", headers: { "Content-Type": "application/json", Prefer: "return=representation" }, body: JSON.stringify(row) });
      return json(res, 200, { item: data[0] || row });
    }
    if (req.method === "DELETE") {
      const id = cleanId(parts[parts.length - 1]);
      const type = parts[parts.length - 2];
      if (!id || !["member", "gallery"].includes(type)) return json(res, 400, { error: "Permintaan hapus tidak valid." });
      const table = type === "member" ? "members" : "gallery";
      const rows = await supabase(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}&select=photo_path`);
      await supabase(`/rest/v1/${table}?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" });
      if (rows?.[0]?.photo_path) await removeImage(rows[0].photo_path);
      return json(res, 200, { ok: true });
    }
    return json(res, 405, { error: "Method tidak didukung." });
  } catch (error) {
    return json(res, 500, { error: error.message || "Server error." });
  }
}
