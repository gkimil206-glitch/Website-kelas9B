-- Jalankan seluruh file ini sekali di Supabase SQL Editor.
-- Bucket publik dipakai hanya untuk membaca foto. Upload/hapus tetap melalui API Vercel.

create extension if not exists pgcrypto;

create table if not exists public.members (
  id text primary key,
  name text not null,
  role text not null default 'Siswa',
  photo text,
  photo_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery (
  id text primary key,
  title text not null,
  photo text not null,
  photo_path text,
  created_at timestamptz not null default now()
);

alter table public.members enable row level security;
alter table public.gallery enable row level security;

insert into storage.buckets (id, name, public)
values ('kelas9b', 'kelas9b', true)
on conflict (id) do update set public = true;

-- API memakai service-role key sehingga tidak membutuhkan policy INSERT/DELETE publik.
-- Foto dapat dibaca publik melalui URL Storage.
