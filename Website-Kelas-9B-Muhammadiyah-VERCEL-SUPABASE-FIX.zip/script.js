const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

const API_URL = "/api/data";
const MAX_IMAGE_BYTES = 1400 * 1024;
let members = [];
let gallery = [];
let toastTimer = null;
let saving = false;

function toast(message) {
  const element = $("#toast");
  if (!element) return;
  element.textContent = String(message);
  element.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => element.classList.remove("show"), 2600);
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (match) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[match]));
}

function makeId(prefix) {
  if (window.crypto && typeof window.crypto.randomUUID === "function") return `${prefix}-${window.crypto.randomUUID()}`;
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

async function api(path = "", options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    cache: "no-store"
  });
  let payload = null;
  try { payload = await response.json(); } catch (_) {}
  if (!response.ok) throw new Error(payload?.error || `Server error ${response.status}`);
  return payload;
}

async function loadData() {
  try {
    const data = await api();
    members = Array.isArray(data?.members) ? data.members : [];
    gallery = Array.isArray(data?.gallery) ? data.gallery : [];
    renderMembers($("#searchMember")?.value || "");
    renderGallery();
    setOnlineState(true);
  } catch (error) {
    members = [];
    gallery = [];
    renderMembers();
    renderGallery();
    setOnlineState(false);
    toast("Database belum terhubung. Cek konfigurasi Vercel dan Supabase.");
  }
}

function setOnlineState(online) {
  const info = document.querySelector("#databaseStatus");
  if (!info) return;
  info.textContent = online ? "Database online" : "Database belum terhubung";
  info.dataset.online = online ? "1" : "0";
}

function renderMembers(filter = "") {
  const grid = $("#memberGrid");
  const total = $("#totalAnggota");
  const empty = $("#emptyState");
  if (!grid) return;
  grid.innerHTML = "";
  const query = String(filter).toLowerCase();
  const list = members.filter((item) => String(item.name || "").toLowerCase().includes(query));
  if (total) total.textContent = `${members.length} Siswa`;
  if (empty) empty.style.display = list.length ? "none" : "block";
  list.forEach((item) => {
    const card = document.createElement("article");
    card.className = "member-card reveal show";
    const img = item.photo || "images/default-avatar.svg";
    card.innerHTML = `
      <img class="member-photo" src="${esc(img)}" alt="${esc(item.name)}" loading="lazy" decoding="async">
      <div class="member-content">
        <small>Nama</small><h3>${esc(item.name)}</h3>
        <div class="role">${esc(item.role || "Siswa")}</div>
        <div class="card-actions">
          <button class="small-btn" type="button" data-edit="${esc(item.id)}">Edit</button>
          <button class="small-btn delete" type="button" data-delete="${esc(item.id)}">Hapus</button>
        </div>
      </div>`;
    grid.appendChild(card);
  });
}

function renderGallery() {
  const grid = $("#galleryGrid");
  const empty = $("#galleryEmpty");
  if (!grid) return;
  grid.innerHTML = "";
  if (empty) empty.style.display = gallery.length ? "none" : "block";
  gallery.forEach((item) => {
    const card = document.createElement("article");
    card.className = "gallery-card reveal show";
    card.innerHTML = `
      <img src="${esc(item.photo || "")}" alt="${esc(item.title)}" loading="lazy" decoding="async">
      <div class="gallery-caption"><strong>${esc(item.title)}</strong>
      <button class="gallery-delete" type="button" data-gdelete="${esc(item.id)}">Hapus</button></div>`;
    grid.appendChild(card);
  });
}

function openModal(id) { document.getElementById(id)?.classList.add("show"); }
function closeModal(id) { document.getElementById(id)?.classList.remove("show"); }

function resetPreview(box, text = "Foto akan tampil di sini") {
  if (box) box.textContent = text;
}

function compressImage(file) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error("Pilih foto terlebih dahulu."));
    if (!/^image\/(jpeg|png|webp)$/i.test(file.type)) {
      reject(new Error("Gunakan foto JPG, PNG, atau WEBP."));
      return;
    }
    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const maxSide = 1600;
        const scale = Math.min(1, maxSide / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
        const width = Math.max(1, Math.round((img.naturalWidth || img.width) * scale));
        const height = Math.max(1, Math.round((img.naturalHeight || img.height) * scale));
        const canvas = document.createElement("canvas");
        canvas.width = width; canvas.height = height;
        const ctx = canvas.getContext("2d", { alpha: false });
        if (!ctx) throw new Error("Perangkat tidak mendukung pemrosesan foto.");
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        let quality = 0.82;
        let dataUrl = canvas.toDataURL("image/jpeg", quality);
        while (dataUrl.length > MAX_IMAGE_BYTES * 1.37 && quality > 0.5) {
          quality -= 0.08;
          dataUrl = canvas.toDataURL("image/jpeg", quality);
        }
        const base64 = dataUrl.split(",")[1] || "";
        if (!base64 || base64.length > MAX_IMAGE_BYTES * 1.37) throw new Error("Foto terlalu besar setelah dikompres.");
        resolve({ dataUrl, base64, contentType: "image/jpeg" });
      } catch (error) { reject(error); }
      finally { URL.revokeObjectURL(objectUrl); }
    };
    img.onerror = () => { URL.revokeObjectURL(objectUrl); reject(new Error("Foto tidak dapat dibaca. Gunakan JPG, PNG, atau WEBP.")); };
    img.src = objectUrl;
  });
}

function previewImage(input, box) {
  if (!input || !box) return;
  input.addEventListener("change", async () => {
    const file = input.files?.[0];
    if (!file) { resetPreview(box); return; }
    try {
      const result = await compressImage(file);
      box.innerHTML = `<img src="${result.dataUrl}" alt="Preview foto">`;
    } catch (error) {
      input.value = "";
      resetPreview(box);
      toast(error.message || "Foto tidak dapat dibaca.");
    }
  });
}

async function saveMember(payload) {
  if (saving) return;
  saving = true;
  try {
    toast("Mengunggah foto...");
    const data = await api("/member", { method: "POST", body: JSON.stringify(payload) });
    if (data?.item) {
      const index = members.findIndex((item) => item.id === data.item.id);
      if (index >= 0) members[index] = data.item; else members.unshift(data.item);
    }
    renderMembers($("#searchMember")?.value || "");
    closeModal("memberModal");
    toast("Data anggota tersimpan");
  } catch (error) { toast(error.message || "Data anggota gagal disimpan."); }
  finally { saving = false; }
}

async function saveGallery(payload) {
  if (saving) return;
  saving = true;
  try {
    toast("Mengunggah foto...");
    const data = await api("/gallery", { method: "POST", body: JSON.stringify(payload) });
    if (data?.item) gallery.unshift(data.item);
    renderGallery();
    closeModal("galleryModal");
    toast("Foto berhasil ditambahkan");
  } catch (error) { toast(error.message || "Foto gagal diunggah."); }
  finally { saving = false; }
}

const openAdd = $("#openAdd");
openAdd?.addEventListener("click", () => {
  $("#memberForm")?.reset();
  if ($("#memberId")) $("#memberId").value = "";
  if ($("#memberModalTitle")) $("#memberModalTitle").textContent = "Tambah Anggota";
  resetPreview($("#photoPreview"));
  openModal("memberModal");
});

const openGallery = $("#openGallery");
openGallery?.addEventListener("click", () => {
  $("#galleryForm")?.reset(); resetPreview($("#galleryPreview")); openModal("galleryModal");
});

$$("[data-close]").forEach((button) => button.addEventListener("click", () => closeModal(button.dataset.close)));
$$(".modal").forEach((modal) => modal.addEventListener("click", (event) => { if (event.target === modal) modal.classList.remove("show"); }));

previewImage($("#memberPhoto"), $("#photoPreview"));
previewImage($("#galleryPhoto"), $("#galleryPreview"));

$("#memberForm")?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const id = $("#memberId")?.value || makeId("member");
  const name = $("#memberName")?.value.trim() || "";
  const role = $("#memberRole")?.value.trim() || "Siswa";
  const file = $("#memberPhoto")?.files?.[0];
  if (!name) return toast("Nama siswa wajib diisi.");
  try {
    let image = null;
    if (file) image = await compressImage(file);
    const existing = members.find((item) => item.id === id);
    await saveMember({ id, name, role, image, oldPhotoPath: existing?.photo_path || null });
  } catch (error) { toast(error.message || "Foto tidak dapat dibaca."); }
});

$("#memberGrid")?.addEventListener("click", async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  const editId = target.dataset.edit;
  const deleteId = target.dataset.delete;
  if (deleteId) {
    if (!confirm("Hapus data anggota ini?")) return;
    try {
      await api(`/member/${encodeURIComponent(deleteId)}`, { method: "DELETE" });
      members = members.filter((item) => item.id !== deleteId);
      renderMembers($("#searchMember")?.value || "");
      toast("Data anggota dihapus");
    } catch (error) { toast(error.message || "Data gagal dihapus."); }
    return;
  }
  if (editId) {
    const item = members.find((value) => value.id === editId);
    if (!item) return;
    $("#memberId").value = item.id;
    $("#memberName").value = item.name || "";
    $("#memberRole").value = item.role || "Siswa";
    $("#memberModalTitle").textContent = "Edit Anggota";
    $("#photoPreview").innerHTML = item.photo ? `<img src="${esc(item.photo)}" alt="Foto">` : "Foto akan tampil di sini";
    openModal("memberModal");
  }
});

$("#searchMember")?.addEventListener("input", (event) => renderMembers(event.target.value));

$("#galleryForm")?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = $("#galleryPhoto")?.files?.[0];
  const title = $("#galleryTitle")?.value.trim() || "";
  if (!file || !title) return toast("Foto dan judul wajib diisi.");
  try {
    const image = await compressImage(file);
    await saveGallery({ id: makeId("gallery"), title, image });
  } catch (error) { toast(error.message || "Foto tidak dapat dibaca."); }
});

$("#galleryGrid")?.addEventListener("click", async (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  const id = target.dataset.gdelete;
  if (!id) return;
  if (!confirm("Hapus foto ini?")) return;
  try {
    await api(`/gallery/${encodeURIComponent(id)}`, { method: "DELETE" });
    gallery = gallery.filter((item) => item.id !== id);
    renderGallery();
    toast("Foto dihapus");
  } catch (error) { toast(error.message || "Foto gagal dihapus."); }
});

const menuBtn = $(".menu-btn");
const nav = $(".nav-links");
if (menuBtn && nav) {
  menuBtn.addEventListener("click", () => nav.classList.toggle("open"));
  $$(".nav-links a").forEach((link) => link.addEventListener("click", () => nav.classList.remove("open")));
}

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add("show"); }), { threshold: 0.1 });
  $$(".reveal").forEach((element) => observer.observe(element));
} else $$(".reveal").forEach((element) => element.classList.add("show"));

window.addEventListener("scroll", () => {
  const progress = $(".progress"); if (!progress) return;
  const height = document.documentElement.scrollHeight - window.innerHeight;
  const percent = height > 0 ? Math.min(100, Math.max(0, (window.scrollY / height) * 100)) : 0;
  progress.style.width = `${percent}%`;
}, { passive: true });

const birthdayData = [
  { name: "Ghysta", day: 4, month: 6, year: 2011 }, { name: "Kasih", day: 20, month: 7, year: 2011 },
  { name: "Sahra", day: 15, month: 1, year: 2012 }, { name: "Sasa", day: 12, month: 4, year: 2012 },
  { name: "Ribhia", day: 12, month: 4, year: 2012 }, { name: "Tegar S.", day: 1, month: 10, year: 2011 },
  { name: "Akbar", day: 14, month: 8, year: 2011 }, { name: "Dido", day: 12, month: 11, year: 2012 },
  { name: "Putri", day: 20, month: 10, year: 2012 }, { name: "Dera", day: 9, month: 10, year: 2012 },
  { name: "Wahyu", day: 27, month: 10, year: 2011 }, { name: "Albar", day: 1, month: 9, year: 2011 },
  { name: "Finas", day: 7, month: 2, year: 2012 }, { name: "Arya", day: 2, month: 2, year: 2012 },
  { name: "Bima", day: 25, month: 2, year: 2012 }, { name: "Yuda", day: 27, month: 7, year: 2010 },
  { name: "Fathan", day: 28, month: 1, year: 2012 }, { name: "Alhaj", day: 21, month: 10, year: 2012 },
  { name: "Hafidz", day: 22, month: 12, year: 2011 }, { name: "Tegar K.", day: 18, month: 3, year: 2012 },
  { name: "Bayu", day: null, month: null, year: null }, { name: "Naufal", day: null, month: null, year: null },
  { name: "Saputra", day: null, month: null, year: null }, { name: "Uni", day: null, month: null, year: null }
];
const birthdayMonths = ["", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
function renderBirthdays() {
  const list = $("#birthdayList"); if (!list) return;
  const search = ($( "#birthdaySearch")?.value || "").trim().toLowerCase();
  const month = Number($("#birthdayMonth")?.value || 0);
  const filtered = birthdayData.filter((person) => person.name.toLowerCase().includes(search) && (!month || person.month === month)).sort((a,b) => (!a.month ? 1 : !b.month ? -1 : (a.month-b.month)||(a.day-b.day)||a.name.localeCompare(b.name)));
  if ($("#birthdayCount")) $("#birthdayCount").textContent = `${filtered.length} Data`;
  list.innerHTML = filtered.length ? filtered.map((person,index) => `<article class="birthday-card"><div class="birthday-number">#${index+1}</div><div class="birthday-name">${esc(person.name)}</div><div class="birthday-date">${esc(person.day ? `${person.day} ${birthdayMonths[person.month]} ${person.year}` : "Tanggal belum diketahui")}</div><div class="birthday-age">${person.day ? "Tanggal lahir tercatat" : "Belum ada data tanggal lahir"}</div></article>`).join("") : '<div class="birthday-empty">Data ulang tahun tidak ditemukan.</div>';
}
$("#birthdaySearch")?.addEventListener("input", renderBirthdays);
$("#birthdayMonth")?.addEventListener("change", renderBirthdays);
renderBirthdays();

(function themeController() {
  const root = document.documentElement, toggle = $("#themeToggle"), label = $("#themeIcon");
  let theme = "light";
  try { theme = localStorage.getItem("kelas9b_theme") || "light"; } catch (_) {}
  if (theme !== "dark" && theme !== "light") theme = "light";
  function applyTheme(value) {
    const dark = value === "dark";
    root.setAttribute("data-theme", dark ? "dark" : "light");
    if (label) label.textContent = dark ? "Terang" : "Gelap";
    if (toggle) { toggle.setAttribute("aria-label", dark ? "Aktifkan mode terang" : "Aktifkan mode gelap"); toggle.setAttribute("title", dark ? "Mode terang" : "Mode gelap"); }
  }
  applyTheme(theme);
  toggle?.addEventListener("click", () => {
    const next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    applyTheme(next); try { localStorage.setItem("kelas9b_theme", next); } catch (_) {}
  });
})();

loadData();
